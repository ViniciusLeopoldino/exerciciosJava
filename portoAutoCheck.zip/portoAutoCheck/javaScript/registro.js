const registerButton = document.getElementById("saveButton");
registerButton.addEventListener("click", function() {
    // Redirecionar para a página de login
    window.location.href = "login.html";
});

const returnButton = document.getElementById("returnButton");
returnButton.addEventListener("click", function() {
    // Redirecionar para a página de login
    window.location.href = "login.html";
});