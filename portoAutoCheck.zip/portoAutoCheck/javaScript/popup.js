  const registerButton = document.getElementById("registerButton");
  registerButton.addEventListener("click", function() {
      // Redirecionar para a página de registro
      window.location.href = "menu.html";
  });
