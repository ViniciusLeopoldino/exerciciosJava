function changeContent(contentId) {
    var contents = document.getElementsByClassName('conteudo');
    for (var i = 0; i < contents.length; i++) {
        contents[i].style.display = 'none';
    }
    document.getElementById(contentId).style.display = 'block';
}

const editButton = document.getElementById("editButton");
editButton.addEventListener("click", function() {
    // Redirecionar para a página de registro
    window.location.href = "menu.html";
});

const returnButton = document.getElementById("returnButton");
returnButton.addEventListener("click", function() {
    // Redirecionar para a página de registro
    window.location.href = "menu.html";
});

